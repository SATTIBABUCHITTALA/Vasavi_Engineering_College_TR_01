package com.vasavi2;

public class StringDemo {
	
	
	public static void main(String args[]) {
		
		//Immutable nature 
		String str="Vasavi Enginnering CollEge";
		
		//convert the string to uppercase 
		String uppercase= str.toUpperCase();
		
		System.out.println(str.toUpperCase());
		
		//convert to Lowercase
		System.out.println(str.toLowerCase());
		
		//split the String into words 
		//output ---> Vasavi, Enginnering, College 
		
		String[] str1=str.split(" " );
		
		for(int i=0;i<str1.length;i++) { //str1.length = 
			System.out.println(str1[i]);
		}
		
		//Vasavi , Enginnering, College 
		for (String value  : str1) {
			System.out.println(value );
		}
		
		//check the String presence 
		System.out.println(str.toLowerCase().contains("coLLege".toLowerCase()));
		
		//String comparision .
		System.out.println(str.equals(uppercase)); //
		
		//replace function 
		System.out.println(str.replace("e", "A"));
		
	}

}
