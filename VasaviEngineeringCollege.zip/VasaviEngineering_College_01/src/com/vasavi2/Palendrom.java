package com.vasavi2;
import java.lang.StringBuffer;
import java.lang.StringBuilder;

public class Palendrom {

	public static void main(String args[]) {
		
		String str="Liril";
		
		String str1="";
		
		char[] ch=str.toCharArray();
		for(int i=ch.length-1;i>=0;i--) {
			
			str1=str1+ch[i];
		}
		if(str.equalsIgnoreCase(str1)) {
			System.out.println("Given String is Palendrom: "+ str);
		}else {
			
			System.out.println("Given String is not Palendrom: "+ str);
		}
		
	}
}
