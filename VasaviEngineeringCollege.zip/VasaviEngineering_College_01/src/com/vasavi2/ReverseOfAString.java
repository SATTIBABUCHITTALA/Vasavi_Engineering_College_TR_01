package com.vasavi2;

public class ReverseOfAString {

	
	public static void main(String args[]) {
		//Reverse the String each and every word should be reversed but not position of the word. 
		String str="Satti Babu Chittala";  //ittaS ubaB alattihC
		//psudo code 
		//Split the String into small Strings str.sprlit(" "); 
		//1. We convert this string to individual charaters char[] ch={P,u,r,m,i,l,a } length= 7, lastindex =6-0 
		// String str1; 
		//iterate this Charater Array in reverse order and Assign each character to str1. 
		
		
		
		
		String str1="";
		
		//6
		String[] strsplit =str.split(" " );  //{"Satti", "Babu", "Chittala"}
		for(int j=0;j<strsplit.length;j++) {
			
		char[] ch=strsplit[j].toCharArray();
		for(int i=ch.length-1;i>=0;i--) {
			
			str1=str1+ch[i];
		}
		str1=str1+" ";
		
		
		}
		
		System.out.println(str1);
		
		
	}
}
