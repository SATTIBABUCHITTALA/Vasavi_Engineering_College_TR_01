package com.vasavi2;

import com.vasavi.AccessModifiers;

public class Main {

	public static void main(String args []) {
		
		AccessModifiers accessModifiers=new AccessModifiers();
		System.out.println(accessModifiers.name);
		System.out.println(accessModifiers.age);
		System.out.println(accessModifiers.collegeName);
		
		
	}
}
