package com.vasavi2;

public class StringBuilder {
	
	//1 year 
	


	//10 people i can complete in 1 -2 months 
	//
	//Not Synchronized Cant be used in Multithreading Environment 
	//StringBuffer is Synchronized  in MultiThreading concept 
	public static void main(String arg[]) {
		
		
		StringBuffer str=new StringBuffer("Vasavi"); //unique characters in the given string s,i 
		//character array
		//count =2
		
	
		str.append(" Engineering");
		str.charAt(0);
		str.deleteCharAt(3);
		System.out.println(str.indexOf("u")); //Get the postion of a character or String -1 
		
		//
		System.out.println(str);
		
	}
}
