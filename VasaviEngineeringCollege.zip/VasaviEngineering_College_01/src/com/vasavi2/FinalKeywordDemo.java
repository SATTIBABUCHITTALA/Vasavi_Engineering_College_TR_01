package com.vasavi2;

 class Vehicle {
	
	String vehicleName;
	String engineNo;
	public  String registrationNumber = "MH0597879";
	String ownerNumber;
	String fulType;
	
	
	public  void getData() {
		System.out.println("In Vehicle");
	}
	
	public Vehicle() {
		this("KMT");
		System.out.println("Vehicle Default");
		
	}
	public Vehicle(String str) {
		
		System.out.println("Vehicle Paramerter "+ str);
	}
	
}
class Car extends Vehicle{
	
	@Override
	public void getData() {
		
		
		System.out.println("In Car");
	}
	public Car() {
		
		super();
	}
}
class Bike extends Vehicle{
	
	
	public void getData() {
		
		System.out.println("In Bike");
		super.getData();
	}
	
	
}

public class FinalKeywordDemo {
	
	
	public static void main(String args []) {
		
		Bike bike=new Bike();
		bike.vehicleName="KMT";
		bike.engineNo="kjljl";
		
		bike.getData();
		
	}
	
	

}
