package com.vasavi2;

class Book{
	
	public String bookId;
	
	public void setBookId(String bookId) {
		//this keyword is used to represent the current instance of a class 
		this.bookId=bookId;
		
	}
	
	
}

public class ThisKeyword {

	
	public static void main(String args[]) {
		
		Book book=new Book();
		book.setBookId("101");
		
		System.out.println("Book Id "+ book.bookId);
		
	}
	
}
