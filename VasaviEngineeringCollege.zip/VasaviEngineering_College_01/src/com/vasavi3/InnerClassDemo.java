package com.vasavi3;

import com.vasavi3.OuterClass.InnerClass;

class OuterClass{
	public String name;
	
	public void setName(String name) {
		this.name=name;
	}
	
public	class InnerClass {
		
		String name2;
		
	public	void setName2(String name2) {
			this.name2=name2;
		}
		
	}
	
	
	
}

public class InnerClassDemo {

	public static void main(String args[]) {
		
		OuterClass outer=new OuterClass();
		
		InnerClass innerclass=outer.new InnerClass();
		
		outer.name="Satti babu";
		
		innerclass.name2="Satti babu";
		innerclass.setName2("Sattibabu");
		
		
		//We cant 
		
		
		
		
		
		
	}
	
	
}
