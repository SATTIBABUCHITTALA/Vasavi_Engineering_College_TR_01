package com.vasavi3;

interface StudentService{
	String getStudentName(String stdId); 
	
	String getName();// public  final abstract 
	
	
}




public class AnanymousInnerClass {

	public static void main(String args[]) {
		
		//boiler plate code
		
		
		
		StudentService service=new StudentService() {

			@Override
			public String getStudentName(String stdId) {if(stdId.equals("101")) {
				return "Satti Babu";
			}else {
				
				return "Student Details are not found !";
			}
			
			
			}

			@Override
			public String getName() {
				// TODO Auto-generated method stub
				return "Hi Friends";
			}
			
		};
		service.getStudentName("101");
	}
	
	
}
