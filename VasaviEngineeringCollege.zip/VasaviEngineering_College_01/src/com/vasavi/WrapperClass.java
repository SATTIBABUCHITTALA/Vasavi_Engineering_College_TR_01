package com.vasavi;

public class WrapperClass {

	public static void main(String args[]) {
		
		int num=10;
		String n="80";
		String str=String.valueOf(num);
		Integer num1=Integer.parseInt(n);
		System.out.println(num1);
		
		
		
	}
	
	
}
