package com.vasavi.hackerrank;

import java.util.Scanner;

//Find out the Password by using th below logic
//Sum of Stable numbers - sum of Unstable Numbers

//1414 -----2,2 --- stable number 
//153 ----1,1,1 ---- stable number
//1125 ----1=2, 2=1, 5=1 unstable number 
class FindPassword{
	
	int getPassword(int[] array) {
		
		int password=0,stable=0,unstable=0,max=0,flag=0;
		//5454
		int temp;
		int[] duplicate=new int[10]; // 0 1 2 3 4 5 6 7 8 9 The frequency will be stored in each index in the array.  
		for(int i=0;i<array.length;i++) {
			temp=array[i];
			 for(int j=0;j<10;j++) 
				 duplicate[j]=0;
			while(array[i]>0) {
				//4545//duplicate[5] =1
				duplicate[array[i]%10]++; 
				array[i]/=10;				
			}
			max=0;
			for(int j=0;j<10;j++) {
				//System.out.print(duplicate[j]+" ");
				if(duplicate[j]>max)
					max=duplicate[j];				
			}
			System.out.println("Max value"+max);
			flag=0;
			for(int j=0;j<10;j++) {
				if(duplicate[j] !=max && duplicate[j] !=0) {
					flag=1;
					break;				
				}				
			}
			
			if(flag==1) {
				unstable+=temp;
			}else {
				stable+=temp;
			}
			password= Math.abs(stable-unstable);
	
		}
		return password;
	}
	
	
}




public class FindPasswordStableNumbers {

	
	public static void main(String args[]) {
		
		Scanner scr=new Scanner(System.in);
		
		System.out.println("Enter How many numbers you want to take ");
		
		int nos=scr.nextInt();
		int [] array=new int[nos];
		
		for(int i=0;i<nos;i++) {
			System.out.println("Please Enter "+(i+1) +" Number ");
			array[i]=scr.nextInt();
			
		}
		FindPassword findPassword =new FindPassword();
		System.out.println("Password for the Given Numbers is "+ findPassword.getPassword(array));
		
		//29+17= 46-223 === 177
	}
	
}
