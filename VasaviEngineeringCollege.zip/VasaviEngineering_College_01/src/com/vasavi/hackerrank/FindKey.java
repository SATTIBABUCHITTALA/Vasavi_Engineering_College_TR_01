package com.vasavi.hackerrank;

import java.util.Scanner;

class KeyProvider{
	
	int findKey(int num1, int num2, int num3) {
		int key=0;
		key=largestOrSmallestDigit(num1,'l')+ largestOrSmallestDigit(num2, 'l')+largestOrSmallestDigit(num3,'l')+largestOrSmallestDigit(num1, 's')+largestOrSmallestDigit(num2, 's')+largestOrSmallestDigit(num3, 's');
		
		System.out.println("Key provider");
		return key;
	}
	int largestOrSmallestDigit(int num, char ch) {
		int digit=0;
		int count=0; //19+ 1+4+5 =29; //7654 =4
		int smallest=1; 
		
		while(num >0) {
			
			int rem=num%10;  //7654
			if(count==0) {
				digit=rem; //4< 5 digit=5;digit=6
				count++;
			}
			if((ch=='l' && digit<rem) || (ch=='s' && digit>rem)){
				digit=rem;
				
			}
			num=num/10;
		System.out.println(digit);
			
		}
		
		return digit;
	}
	
}




public class FindKey {

	public static void main(String args[]) {
		
		Scanner scr=new Scanner(System.in);
		
		System.out.println("Please Enter First Number ");
	
		
		int num1=scr.nextInt();
		
System.out.println("Please Enter Second Number ");
	
		
		int num2=scr.nextInt();
		
System.out.println("Please Enter Third Number ");
	
		
		int num3=scr.nextInt();
		KeyProvider key=new KeyProvider();
		
		System.out.println(key.findKey(num1, num2, num3));
		
	}
}
