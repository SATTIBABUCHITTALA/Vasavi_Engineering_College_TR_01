package com.vasavi.hackerrank;

public class SortOutBasedOnFirstCharacter {

	
	public static void main(String args[]) {
		
		String str[] = { "Purmila", "Saranya", "Hema", "Shanmuka", "Shanmuka Rama", "Kyathi", "Sowjanya", "Renuka", "Lanvanya", "Reshma"};
		for(String str1 :str) {
			
			System.out.print(str1 + " ");
		}
		System.out.println();
		
		for(int i=0;i<str.length;i++) {
			String temp;
			
			for(int j=i;j<str.length-1;j++) {
			
			if(str[i].charAt(0) > str[j].charAt(0)) {
				temp=str[i];
				str[i]=str[j];
				str[j]=temp;
				
				
			}
			}
			
			
		}
		System.out.println("After sorting ");
		for(String str1 :str) {
			
			System.out.print(str1+ " ");
		}
	}
	
}
