package com.vasavi.hackerrank;

import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONObject;
public class CreatingJSONDocument {
   public static void main(String args[]) {
      //Creating a JSONObject object
      JSONObject jsonObject = new JSONObject();
      //Inserting key-value pairs into the json object
      jsonObject.put("ID", "1");
      jsonObject.put("First_Name", "Shikhar");
      jsonObject.put("Last_Name", "Dhawan");
      jsonObject.put("Date_Of_Birth", "1981-12-05");
      jsonObject.put("Place_Of_Birth", "Delhi");
      jsonObject.put("Country", "India");
      JSONObject jsonObject1 =new JSONObject();
      jsonObject1.put("ID", "2");
      jsonObject1.put("First_Name", "Mani");
      jsonObject1.put("Last_Name", "Dhawan");
      jsonObject1.put("Date_Of_Birth", "1981-12-04");
      jsonObject1.put("Place_Of_Birth", "Andhra");
      jsonObject1.put("Country", "India");
      try {
         FileWriter file = new FileWriter("C:\\Users\\schitta\\Desktop\\output.json");
         file.write(jsonObject.toJSONString());
         file.write(jsonObject1.toJSONString());
         file.close();
      } catch (IOException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      System.out.println("JSON file created: "+jsonObject);
   }
}
