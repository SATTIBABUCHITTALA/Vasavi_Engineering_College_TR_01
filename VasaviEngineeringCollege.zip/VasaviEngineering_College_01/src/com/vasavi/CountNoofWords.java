package com.vasavi;

import java.util.Scanner;

public class CountNoofWords {

	public static void main(String args[]) {
		
		System.out.println("Enter The String");
		Scanner scr=new Scanner(System.in);
		String str=scr.nextLine();
		
		int wordsCount=0;
		int charactersCount=0;
		String[] words=str.split(" ");
		for(int i=0;i<words.length;i++) {
			wordsCount++;
		}
		char[] chararray=str.toCharArray();
		for(int i=0;i<chararray.length;i++) {
			if(chararray[i] !=' ')
			charactersCount++;
		}
		System.out.println("Words Count "+ wordsCount);
		System.out.println("Characters Count "+ charactersCount);
		
		
	}
	
	
}
