package com.vasavi;

class CustomerAccount {
	
	private String accountNumber;
	private double  amount;
	private String dataofOpening;
	private String accountHolderName;
	private String phoneNum;
	private String personId;
	
	
	public String getPersonId() {
		return personId;
	}
	public void setPersonId(String personId) {
		this.personId = personId;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		if(personId =="1010") {
			this.amount = amount;
		}else {
			
		}
		
	}
	public String getDataofOpening() {
		return dataofOpening;
	}
	public void setDataofOpening(String dataofOpening) {
		this.dataofOpening = dataofOpening;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	
	//whatever the modifications we want to do we will do it through a methods instead of changing directly 
	
	
	
	
	
}



public class EncapsulationDemo {

	public static void main(String args[]) {
		
		CustomerAccount customerAccount=new CustomerAccount();
		
		/*
		 * customerAccount.accountNumber ="13465637373";
		 * customerAccount.accountHolderName ="Satti babu"; customerAccount.amount =
		 * 100; customerAccount.phoneNum ="1234567878";
		 */
		
		customerAccount.setAccountHolderName("Satti babu");
		customerAccount.setAccountNumber("13465637373");
		customerAccount.setAmount(100000);
		customerAccount.setPhoneNum("9004989074" );
		customerAccount.setDataofOpening("12-02-2010");
		customerAccount.setPersonId("10101");
		
		
		
		
	}
}
