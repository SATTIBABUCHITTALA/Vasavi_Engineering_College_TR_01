package com.vasavi;

public class TypeCasting {
	
	
	public static void main(String args[]) {
		
		int i=10;
		
		double d=10.35;
		
		float f=10.56f;
		
		
		i=(int) d; // Narrowing 
		
		//lower datatype---> Higher Datatype No issues
		//dog --> elephant
		//
		
		//dog and elephant 
		//dog can sit in elephant place
		//elephant cant adjust in dog place 
		d=i; //widening 
		System.out.println("Integer "+i);
		System.out.println("Float "+f);
		System.out.println("Double "+d);
		
		
		
		
	}

}
