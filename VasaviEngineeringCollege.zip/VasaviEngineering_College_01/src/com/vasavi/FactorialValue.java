package com.vasavi;

class Operations {
	int factorial(int num) { //4/3/2/2
		int factorial=1; 
		
		if(num>0) {
		if(num>=1 ) {
			
			return num*factorial(num-1);
		}else {
			return 1;
		}}else {
			return 0;
		}
		}
}

public class FactorialValue {

	public static void main(String args[]) {
		Operations operation=new Operations();
		System.out.println(operation.factorial(5));		
	}
}
