package com.vasavi.thread;

class StudentClass extends Thread {
	
	
	public void run() {
		System.out.println("Thread 1");
		try {
			getValue();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	void getValue() throws InterruptedException {
		for(int i=0;i<100;i++)
		System.out.println("I Value"+ i);
		
		Thread.sleep(1000);
	}
}



public class ThreadDemo {
	
public static void main(String args[]) throws InterruptedException {
	
	
	StudentClass stdClass=new StudentClass();
	
	
	stdClass.start();
	stdClass.sleep(1000);
	
	
	
	StudentClass stdClass2=new StudentClass();
	
	stdClass2.start();
	stdClass2.sleep(1000);
	
	
	
	
}
	
	
	
	

}
