package com.vasavi;

class Access{
	
	public String name; //defalut 
	private int age; //visibility of my variables 
	protected String collegeName; //by creating an object for the class 
	
	
}


//Tpg, Vasavi 

public class AccessModifiers {
	
	public String name; //defalut 
	public int age; //visibility of my variables 
	public String collegeName;
	
	
	public static void main(String args[]) {
		
		
		
		Access access =new Access();
		access.name="Madhu";
		//access.age=21;
		access.collegeName="Vasavi";
		
	}
	
	
}
