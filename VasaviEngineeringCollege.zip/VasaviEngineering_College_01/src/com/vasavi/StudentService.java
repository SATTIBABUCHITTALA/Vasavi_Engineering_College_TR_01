package com.vasavi;

public interface StudentService {

	
	 void getStudentDetails(int stdId);
	 void getDetails();//abstract methods 
	
	//java 8  version 1, 17,19 
	
	
}
