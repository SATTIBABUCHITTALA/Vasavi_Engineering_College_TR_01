package com.vasavi;

import java.util.Scanner;

public class FindPalendrom {

	public static void main(String args[]) {
		
		System.out.println("Please Enter any String: ");
		
		Scanner scr=new Scanner(System.in);
		String str=scr.nextLine();
		char[] ch=str.toCharArray();
		String str1="";
		
		for(int i=ch.length-1;i>=0;i--) {
			
			str1+=ch[i];
			
		}
		System.out.println(str);
		System.out.println(str1);
		if(str.equalsIgnoreCase(str1)) {
			System.out.println("Given String is Palendrom "+ str);
		}else {
			System.out.println("Given String is not Palendrom "+str);
		}
		
	}
	
	
}
