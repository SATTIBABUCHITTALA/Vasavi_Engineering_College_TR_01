package com.vasavi;

public class PrimeNumber {

	public static void main(String args[]) {
		
		int num= -9887891; //2,3, 5, 7, 11, 13, 17, 19, 23, 29
		
		//1. I need to check the divisible of each and every number from 1 to less than the given number
		//7 === 2 -3-6 count =0  1,2,3,4,5,6,7
		//for loop , while ,
		
		int count=0;
		
		if(num>1) {
			
		for(int i=2;i<num/2;i++) {
		
			if(num%i == 0)
				count++;
		}
		
		if(count == 0) //count should be 2
			System.out.println("Given number is prime "+num);
		else
			System.out.println("Given number is not prime "+num);
		
		}else {
			System.out.println("Invalid input ");
		}
		
		
	}
	
	
}
