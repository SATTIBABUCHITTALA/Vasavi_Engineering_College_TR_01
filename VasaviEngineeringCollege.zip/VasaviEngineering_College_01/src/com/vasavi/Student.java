package com.vasavi;


class StudentDetails{
	
	//Instance Variables 
	String name;
	String grade;
	String phoneNum; //instance variable or non-static variables 
	static String collegeName ; //class Variable 
	String rollNo;
	
	String getStudentName(String sdRollNo) {
		
		String studentName="Ramesh"; //local Variable 
		
		if(sdRollNo =="101")
		return studentName;
		else 
			return " Invalid Roll No";		
	}
	
	static {
		
		System.out.println(" I am a static block ");
		
	}
	
	//do we need to provide returntype for constructor ?
	public StudentDetails() {
		System.out.println("Constructor ");
	}
	//studentName="Hello";
	
	public StudentDetails(String clgName) {
		collegeName =clgName;
	}
	//what is the return type of an object 
	public StudentDetails(StudentDetails std) {
		this.name=std.name;
		
	}
	
	
	}
public class Student {
	
	public static void main(String args[]) {
		
		
		
		StudentDetails stdDetails=new StudentDetails("Vasavi");
		stdDetails.name="Ramesh";
		stdDetails.rollNo="101";
		stdDetails.phoneNum="98749797";
		
		
		//1000 students are there 
		//
		
		StudentDetails stdDetails1=new StudentDetails(stdDetails);
		
		stdDetails1.name="Shruthi";
		stdDetails1.rollNo="103";
		//stdDetails1.phoneNum="9874978787";
		//stdDetails1.collegeName="Vasavi";
		
		System.out.println(stdDetails.name);
		System.out.println(stdDetails.rollNo);
		System.out.println(stdDetails.phoneNum);
		System.out.println(stdDetails.collegeName);
		
		System.out.println();
		System.out.println(stdDetails1.name);
		System.out.println(stdDetails1.rollNo);
		System.out.println(stdDetails1.phoneNum);
		System.out.println(stdDetails1.collegeName);
		
		//StudentDetails.collegeName;
		
		StudentDetails stdDetails2=new StudentDetails();
		StudentDetails stdDetails3=new StudentDetails();
		
		
		
		
	}

}
