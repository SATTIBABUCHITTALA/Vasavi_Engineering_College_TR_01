package com.vasavi;

public class ArrayDemo {

	public static void main(String args[]) {
		
		int[] array=new int[10];
		
		
		
		
		
		
		for(int i=0;i<array.length;i++) { //0,1,2,3,4,5,6,7,8,9
			array[i]= 2; 
			
			//System.out.println(array[i]);
		}
		//accessing the Two Dimensional Array 
		int[][] matrix =new int[5][5]; //4 rows and 3 columns 
		for(int i=0;i<5;i++) { //0 1
			
			for(int j=0;j<5;j++) {
				matrix[i][j] = i+j;
				System.out.print("*  ");
				
			}
			System.out.println();
		}
		
		
		
		
	}
	
	
}
