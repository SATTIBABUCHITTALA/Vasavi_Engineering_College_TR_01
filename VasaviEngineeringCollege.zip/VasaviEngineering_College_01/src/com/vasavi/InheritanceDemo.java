package com.vasavi;

class Book{
	
	String bookId;
	String bookName;
	String author;
	double price ;
	
	double getPrice (String bookId ) {
		
		if(bookId == "101") {
			price = 400.50;
		}else if(bookId =="102") {
			
			price =600.00;
		}else {
			System.out.println("BookId not Found !! ");
		}
		
		return price;
		
		
	}
	
	
}

class Library extends Book {
	
	String [] books = {"Java", "Unix", "Python", "DBMS","C" };
	
	
	
	String getBookName(String bookName) {
		String available="Book is not Available";
		
		for(int i=0;i<books.length;i++) {
			
			if(bookName == books[i]) {
				
				available= "Book is Available" ;
			}
		}
		return available;
		
		
	}
	
	
	
}


public class InheritanceDemo {
	
	public static void main(String args[]) {
		
		
	Book book=new Book();
	book.bookId="101";
	book.bookName="Java";
	book.author="Bala guruswamy";
	
	Library library=new Library();
	System.out.println(library.getBookName("Java"));
	 
		
	}

}
