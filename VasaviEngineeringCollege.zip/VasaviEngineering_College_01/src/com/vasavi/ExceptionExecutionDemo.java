package com.vasavi;


class ExceptionDemo{
	
	public Integer getValue() {
		
		Integer value=10;
		try {
			value=20;
			throw new Exception();
		}catch(Exception e) {
			System.out.println("In Catch Block");//Global Exception 
			value=30;
			
		}finally {
			
			value=50;
		}
		
		return value;
	}
	
	//If Exception does not occur --> 40;
	//If Exception occurs ---> 40
}


public class ExceptionExecutionDemo {
	public static void main(String args[]) {
		
		ExceptionDemo exceptionDemo= new ExceptionDemo();
		System.out.println(exceptionDemo.getValue());
		
		
	}

}
