package CollectionFrameWork;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MapInterfaceDemo {
	
	
	public static void main(String args[]) {
		
		Map<Integer, String> hashMap=new HashMap();
	
		hashMap.put(6, "Satti babu");
		hashMap.put(20, "Prerna");
		hashMap.put(3, "Hari");
		
		for(Map.Entry<Integer, String> hm: hashMap.entrySet()) {
			
			
			System.out.println(hm.getValue());
			System.out.println(hm.getKey());
		}
		
		
		
		Iterator itr=hashMap.entrySet().iterator();
		
		while(itr.hasNext()) {
			
			System.out.println(itr.next());
			
		}
		
		
		
		
		
		
		
	}
	
	

}
