package CollectionFrameWork;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Movie implements Comparable<Movie> {
	
	String movieId;
	String movieName;
	public String getMovieId() {
		return movieId;
	}
	public void setMovieId(String movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + "]";
	}
	public Movie(String movieId, String movieName) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	@Override
	public int compareTo(Movie o) {  //0,1,-1
		// TODO Auto-generated method stub
		return this.movieId.compareTo(o.movieId);
	}
	
	
	
	
	
}


public class ComparableInterfaceDemo {
	
	
	public static void main(String args[]) {
		
		
		List<Movie> movieList=new ArrayList<Movie>();
		
		
		Comparator<Movie> comparator=new Comparator<Movie>() {

			@Override
			public int compare(Movie o1, Movie o2) {
				// TODO Auto-generated method stub
				return o1.getMovieId().compareTo(o2.getMovieId());
			}
			
		};
		Comparator<Movie> nameComparator=new Comparator<Movie>() {

			@Override
			public int compare(Movie o1, Movie o2) {
				// TODO Auto-generated method stub
				return o1.getMovieName().compareTo(o2.getMovieName());
			}
			
		};
		
		
		
		
		Movie movie=new Movie("101", "Raja The Great");
		movieList.add(movie);
		movie=new Movie("107", "RRR");
		movieList.add(movie);
		movie=new Movie("103", "Acharya");
		movieList.add(movie);
		
		System.out.println(movieList);
		
		//Collections.sort(movieList);
		Collections.sort(movieList, nameComparator);
		
		System.out.println(movieList);
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
