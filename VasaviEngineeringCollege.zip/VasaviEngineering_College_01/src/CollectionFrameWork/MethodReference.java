package CollectionFrameWork;

class Reference{
	
	Number add(Number  num1, Number  num2) {
		
		if(num1.getClass().equals(Integer.class) && num2.getClass().equals(Integer.class))
			
		return num1.intValue()+num2.intValue();	
		
		else if(num1.getClass().equals(Float.class) && num2.getClass().equals(Float.class))
			return num1.floatValue()+num2.floatValue();
		else if(num1.getClass().equals(Double.class) && num2.getClass().equals(Double.class))
			return num1.doubleValue()+num2.doubleValue();
		else 
			return 0;
		
	}
	
	
}
public class MethodReference {

	public static void main(String args[]) {
		
		Reference reference =new Reference();
		System.out.println("Addition of Given numbers is "+ reference.add(20, 30));	
		
		System.out.println("Addition of Given numbers is "+ reference.add(34.5f, 36.7f));
		
		System.out.println("Addition of Given numbers is "+ reference.add(34.566, 36.78));
	}
	
	
}
