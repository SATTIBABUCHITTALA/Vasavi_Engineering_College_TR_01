package CollectionFrameWork;


import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

//POJO class Plain Old Java Object
class StudentList{
	
	private String stdId;
	private String stdName;
	private String grade;
	
	public String getStdId() {
		return stdId;
	}
	public void setStdId(String stdId) {
		this.stdId = stdId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
	
	
}

public class CollectionDemo {

	public static void main(String args [] ) {
		
		
		List<StudentList> studentList=new ArrayList<StudentList>();
		
		
		StudentList student=new StudentList();
		
		student.setStdId("101");
		student.setStdName("Satti Babu");
		student.setGrade("A");
		
		
		studentList.add(student);
		
		student=new StudentList();
		
		student.setStdId("102");
		student.setStdName("Rahul");
		student.setGrade("A+");
		
		studentList.add(student);
		
		System.out.println("Student Id | Student Name | Student Grade ");
		for(StudentList  student1:studentList) {
			System.out.println(student1.getStdId() +"        |  " + student1.getStdName() + "    |    "+ student1.getGrade());
			
			
			
			
			List<String> list=new ArrayList<>();
			
			list.add("Manoj");
			list.add("Kiran");
			list.add("Hari");
			
			
			List<String> nameList=new ArrayList<String>();// ArrayList, LinkedList, Vector, Stack
			nameList.add("SattiBabu");
			nameList.add("Aruna");
			nameList.add("Pavan"); //Pavan
			nameList.add("Sai");
			nameList.add("Bhanu");
			
			nameList.set(2, "Prerna");
			
			
			
			nameList.addAll(list);
			nameList.remove(1);
			
			
			Collections.sort(nameList);
			Iterator itr=nameList.iterator();
			
			while(itr.hasNext()) {
				
				System.out.println(itr.next());
			}
			
			
			
			LinkedList<String> linkedList=new LinkedList<String>();
			linkedList.add("SattiBabu");
			linkedList.addFirst("Hari");
			linkedList.addLast("Kiran");
			
			
			
			
			
			
			
			
			
			
			
			
		}		
		
		
		
		
		
		//list is called a reference Variable 
		//new ArrayList() is called Object Creation Instance
		
		//We can create an instance for a subclass or implemented class and we can use Superclas or Interface as a reference
		
		
		
		
		
		
		
		
		
		
		
	}
	
}
