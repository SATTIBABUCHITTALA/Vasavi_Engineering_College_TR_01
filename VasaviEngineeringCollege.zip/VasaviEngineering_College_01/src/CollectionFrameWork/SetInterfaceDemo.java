package CollectionFrameWork;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.TreeSet;

public class SetInterfaceDemo {
	
	public static void main(String args[]) {
		
		HashSet<Integer> hashSet=new HashSet<Integer>();
		
		//by using some hashcode 
		
		hashSet.add(5);
		hashSet.add(8);
		hashSet.add(76);
		hashSet.add(98);
		
		
		Iterator<Integer> itr=hashSet.iterator();
		
		while(itr.hasNext()) {
			
			System.out.println(itr.next());
		}
		
		LinkedHashSet<Integer> linkedHashSet=new LinkedHashSet();
		
		
		linkedHashSet.add(50);
		linkedHashSet.add(81);
		linkedHashSet.add(76);
		linkedHashSet.add(98);
		
			itr=linkedHashSet.iterator();
		
		while(itr.hasNext()) {
			
			System.out.println(itr.next());
		}
		
		TreeSet<Integer> treeSet=new TreeSet();
		
		
		treeSet.add(50);
		treeSet.add(-81);
		treeSet.add(76);
		treeSet.add(9);
		
			itr=treeSet.iterator();
		
		while(itr.hasNext()) {
			
			System.out.println(itr.next());
		}
		
		
		
		
		
		
	}
	
	
	
	

}
