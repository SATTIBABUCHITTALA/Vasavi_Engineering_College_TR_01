package com.vasavi2;

final class Vehicle {
	
	String vehicleName;
	String engineNo;
	public final String registrationNumber = "MH0597879";
	String ownerNumber;
	String fulType;
	
	
	public final void getData() {
		System.out.println("In Vehicle");
	}
	
}
class Car extends Vehicle{
	
	public void getData() {
		System.out.println("In Car");
	}
	
}
class Bike extends Vehicle{
	
	
	public void getData() {
		System.out.println("In Bike");
	}
	
	
}

public class FinalKeywordDemo {
	
	
	public static void main(String args []) {
		
		Bike bike=new Bike();
		bike.vehicleName="KMT";
		bike.engineNo="kjljl";
		
		bike.getData();
		
		
	}
	
	

}
