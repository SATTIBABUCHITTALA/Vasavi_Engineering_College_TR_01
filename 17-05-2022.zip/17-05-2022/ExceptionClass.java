package com.vasavi2;



class Canteen{
	
	String fans;
	String tables;
	String plates;
	String dish;
	
	int i=10;
	int j=0;
	
	public void getData() {
	try {
	System.out.println(i/j);
	
	
	}catch(ArithmeticException ae) {
		System.out.println("Divisble by Zero is not Possible ");
	}finally {
		System.out.println("Hello Team");
		
		
	}
	System.out.println("Hi");
	System.out.println("Terminated the method Bye bye ");
	}
}


public class ExceptionClass {

	public static void main(String args[]) {
		Canteen canteen =new Canteen();
		canteen.getData();
		
		
	}
	
	
}
