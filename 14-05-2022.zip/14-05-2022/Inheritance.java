package com.vasavi;

class A {
//Method overloading 
void getData(){
	
System.out.println("In Class A ");

}
void getData(int stdId) {
	System.out.println("In Class A modified ");
}
}
class B{

	void getData() {
		System.out.println("Class B");
	}


}
class C extends B{


void getData() {
	System.out.println("Implemntation has been changed");
}

}

public class Inheritance {

	public static void main(String args[]) {
		C c=new C();
		c.getData();
		
		
	}
	
	
}
