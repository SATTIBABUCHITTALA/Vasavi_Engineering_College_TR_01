package com.vasavi;


//Pavan Purmila Saranya 
public class StudentClass {

	public static void main(String args[]) {
		
		A a=new A();
		a.getData();
		a.getData(101);
	}
	
}
