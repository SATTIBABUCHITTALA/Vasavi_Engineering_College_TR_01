package com.vasavi;

public class TypeCasting {
	
	
	public static void main(String args[]) {
		
		int i=10;
		
		double d=10.35;
		
		float f=10.56f;
		
		System.out.println("Integer "+i);
		System.out.println("Float "+f);
		System.out.println("Double "+d);
		
		
		
		
	}

}
