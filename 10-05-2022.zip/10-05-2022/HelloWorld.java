public class HelloWorld{

public static void main(String args[]){

System.out.println("Good Evening");

System.out.println(args[0]);
}

}