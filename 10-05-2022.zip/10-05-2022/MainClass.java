class Student{
String name;
String rollNo;
String grade;

String getStudentName(String rollNo){
String stdName="Purmila";
if(rollNo=="629")
return stdName;
else 
return "Student Not found"; 

}

}
public class MainClass{


public static void main(String args[]){

Student student=new Student();
System.out.println(student.getStudentName("629"));

}
}