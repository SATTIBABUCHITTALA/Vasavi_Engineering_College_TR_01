package com.vasavi;

public class ConditionalStatements {

	
	public static void main(String args[]) {
		
		int i=-96;
		
		//This number should be divisible by 2 reminder should be 0
		//finding prime number 
		// 7 is prime or not 1 ---- 6 only 1 divisible 
		//one and itself divisible then that number is called prime number 
		
// operators
		//airthmetic +,-*, /
		//assignment operators =
		//conditional operators && || 
		//Relational Statements >,<,<=, >= 
		
		if(i>0 && i%2 == 0 ) {
			
			System.out.println("Even Number ");
		}else if(i>0 && i%2 == 1) {
			
			System.out.println("Odd Number ");
		}else  {
			
			System.out.println("Given values is Zero or less than zero !!!");
			
		}
		
		
		int num=10;
		num=num+1; 
		num++; //num=num+1; 
		num--;//num=num-1
	
		//switch case condtional statement 
		
		 num =2; //4 
		 
		 //conditional statement is break and continue 
		 System.out.println("Switch Statement ");
		 //if(num==2 ) case 2: 
		 switch(num) {
		 
		 case 1:
		 	System.out.println("One");
		 	break;
		 case 2:
			 System.out.println("Two");
			 break;
		 case 3:
			 System.out.println("Three");
			 break;
		 case 4:
			 System.out.println("Four");
			 break;
		default:
			System.out.println("Invalid Number");

		 }
		
		
	//looping condtional statements 
		 
		 //for while do-while loops
		 
		 //syntax for(initialization;condition; increment/ decrement) 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 for(int n=1;n<=5;n++) { //n=1, n=2 ,n=3, n=4, n=5,n=6
			 
			 if(n==3)
				 continue;
			 System.out.println("I value "+n); //1,2
			 
			 
		 }
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 //while loop 
		 System.out.println(i); //-96
		 
		/**while(i<0){
			
		System.out.println("I Value"+ i);
		i++; //-96+1 =-95 
			
		}*/
		i=-10;
		do {
			
			System.out.println("hi");
			
		}while(i>0);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
}
