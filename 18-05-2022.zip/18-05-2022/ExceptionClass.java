package com.vasavi2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

class Canteen{
	
	
	int i=10;
	int j=0;
	
	public void getData() throws FileNotFoundException   {
		
		FileInputStream fio=new FileInputStream(new File("C:\\Users\\schitta\\Desktop\\CoreJava_Programs\\Vasavi_Engineerging_01\\17-05-2022\\17-05-2022.txt"));
	System.out.println(i/j);
	System.out.println("Hi");
	System.out.println("Terminated the method Bye bye ");
	}
}


public class ExceptionClass {

	public static void main(String args[]) throws FileNotFoundException   {
		int [] array=new int[5]; //0,1,2,3,4
		
		System.out.println("Array"+ array[5]);
		
		
		Canteen canteen =new Canteen();
		canteen.getData();
		
		
	}
	
	
}
