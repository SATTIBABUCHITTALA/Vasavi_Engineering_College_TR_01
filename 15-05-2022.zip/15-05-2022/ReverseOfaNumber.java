package com.vasavi;

public class ReverseOfaNumber {

	public static void main(String args[]) {
		
		//square of individual digits of a number //
		  int n=12;
	      int ans=0;
	      while(n>0)
	      {
	          int r=n%10;
	          ans=(ans)+r*r;
	          n=n/10;
	      }
	      System.out.println(ans);
	    }
		
	
	
	
}
