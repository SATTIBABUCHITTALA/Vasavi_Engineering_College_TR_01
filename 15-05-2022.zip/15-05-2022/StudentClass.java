package com.vasavi;


interface Service {
	
	//
	
	public  void getDetails();
	void geData();
	
}
class StudentDetails1 implements StudentService,Service {
	
	//Annotation 
	@Override
	public void getStudentDetails(int stdId) {
		// TODO Auto-generated method stub
		System.out.println("Get Details");
	}

	@Override
	public void getDetails() {
		// TODO Auto-generated method stub
		String str="Sattibabu";
		System.out.println(str.substring(0,5));
	}

	@Override
	public void geData() {
		// TODO Auto-generated method stub
		
		
		
	}
	
	
	
}


//Pavan Purmila Saranya 
public class StudentClass {

	public static void main(String args[]) {
		
		StudentDetails1 std=new StudentDetails1();
		std.getStudentDetails(0);
		std.getDetails();
		
		
	}
	
}
